import { ROLE_SECRET_KEY_1 } from '../config/env';

export const roles = {
    1: ROLE_SECRET_KEY_1
};

export const rolesMap = new Map([
    [ROLE_SECRET_KEY_1, "Administrator"]
]);